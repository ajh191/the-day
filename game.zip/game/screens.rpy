﻿################################################################################
## 초기화
################################################################################

init offset = -1


################################################################################
## 스타일
################################################################################

style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)



################################################################################
## 게임내 스크린
################################################################################


## Say 스크린 #####################################################################
##
## Say 스크린은 플레이어에게 대사를 출력할 때 씁니다. 화자 who와 대사 what, 두
## 개의 매개변수를 받습니다. (화자 이름이 없으면 who는 None일 수 있음)
##
## 이 스크린은 id "what"을 가진 텍스트 디스플레이어블을 생성해야 합니다. (이 디
## 스플레이어블은 렌파이의 대사 출력에 필요합니다.) id "who" 와 id "window" 디스
## 플레이블이 존재할 경우 관련 스타일 속성이 적용됩니다.
##
## https://www.renpy.org/doc/html/screen_special.html#say

screen say(who, what):

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "namebox"
                text who id "who"

        text what id "what"


    ## 사이드 이미지가 있는 경우 글자 위에 표시합니다. 휴대폰 환경에서는 보이지
    ## 않습니다.
    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0


## Character 객체를 통해 스타일을 지정할 수 있도록 namebox를 사용할 수 있게 만듭
## 니다.
init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos

    adjust_spacing False

## Input 스크린 ###################################################################
##
## 플레이어 입력을 받는 renpy.input을 출력할 때 쓰이는 스크린입니다. prompt 매개
## 변수를 통해 입력 지문을 표시할 수 있습니다.
##
## 이 스크린은 id "input"을 가진 input 디스플레이어블을 생성해야 합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#input

screen input(prompt):
    style_prefix "input"

    window:

        vbox:
            xanchor gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

screen input_center(prompt):
    style_prefix "input"

    window at textbox_fade:
        yalign 0.5          # 0.0 = 화면 맨 위, 0.5 = 정중앙, 1.0 = 맨 아래

        vbox:
            xanchor gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width


## Choice 스크린 ##################################################################
##
## menu 명령어로 생성된 게임내 선택지를 출력하는 스크린입니다. 한 개의 매개변수
## items를 받고, 이는 선택지 내용(caption)과 선택지 결과(action)이 있는 오브젝트
## 가 들어있는 리스트입니다.
##
## https://www.renpy.org/doc/html/screen_special.html#choice

screen choice(items):
    style_prefix "choice"

    vbox:
        for i in items:
            textbutton i.caption action i.action


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 405
    yanchor 0.5

    spacing gui.choice_spacing

style choice_button is default:
    properties gui.button_properties("choice_button")
    background Solid("#000000cc")
    hover_background Solid("#c9a0b4cc")
    hover_sound "audio/ui_hover.ogg"
    activate_sound "audio/ui_select.ogg"

style choice_button_text is default:
    properties gui.text_properties("choice_button")


## Quick Menu 스크린 ##############################################################
##
## 퀵메뉴는 게임 외 메뉴 접근성을 높여주기 위해 게임 내에 표시됩니다.

screen quick_menu():

    ## 다른 화면 위에 표시되는지 확인합니다.
    zorder 100

    if quick_menu:

        frame:
            xalign 0.5
            yalign 1.0
            ysize 35
            background Solid("#000000b3")
            padding (30, 6)
        
        hbox:
            style_prefix "quick"
            style "quick_menu"

            textbutton _("되감기") action Rollback()
            textbutton _("대사록") action ShowMenu('history')
            textbutton _("넘기기") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("자동진행") action Preference("auto-forward", "toggle")
            textbutton _("저장하기") action ShowMenu('save')
            #textbutton _("Q.저장하기") action QuickSave()
            #textbutton _("Q.불러오기") action QuickLoad()
            textbutton _("도감") action ShowMenu('collection')
            textbutton _("스토리라인") action ShowMenu('storyline')
            textbutton _("설정") action ShowMenu('preferences')


## 플레이어가 UI(스크린)을 일부러 숨기지 않는 한 퀵메뉴가 게임 내에 오버레이로
## 출력되게 합니다.
init python:
    config.overlay_screens.append("quick_menu")

default quick_menu = True

style quick_menu is hbox
style quick_button is default
style quick_button_text is button_text

style quick_menu:
    xalign 0.5
    yalign 1.0

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.text_properties("quick_button")


################################################################################
## Main과 Game Menu 스크린
################################################################################

## Navigation 스크린 ##############################################################
##
## 이 스크린은 메인메뉴와 게임외 메뉴에 포함되어 다른 메뉴로 이동하거나 게임을
## 시작/종료할 수 있게 합니다.

screen navigation():

    vbox:
        style_prefix "navigation"

        xpos gui.navigation_xpos
        yalign 0.5

        spacing gui.navigation_spacing

        if main_menu:

            textbutton _("시작하기") action Start()

        else:

            textbutton _("대사록") action ShowMenu("history")

            textbutton _("저장하기") action ShowMenu("save")

        textbutton _("불러오기") action ShowMenu("load")

        textbutton _("도감") action ShowMenu("collection")

        textbutton _("스토리라인") action ShowMenu("storyline")

        textbutton _("환경설정") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("리플레이 끝내기") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("메인 메뉴") action MainMenu()

        textbutton _("버전정보") action ShowMenu("about")

        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):

            ## 도움말 메뉴는 모바일 디바이스와 맞지 않아 불필요합니다.
            textbutton _("조작방법") action ShowMenu("help")

        if renpy.variant("pc"):

            ## iOS에서는 종료 버튼이 금지되어 있으며 Android 및 웹에서는 불필요
            ## 합니다.
            textbutton _("종료하기") action Quit(confirm=not main_menu)


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")

style navigation_button_text:
    properties gui.text_properties("navigation_button")


## Main Menu 스크린 ###############################################################
##
## 렌파이가 시작할 때 메인메뉴를 출력합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#main-menu

screen main_menu():

    ## 이렇게 하면 다른 메뉴 화면이 모두 교체됩니다.
    tag menu
    use title_layers
    use title_menu

style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_frame:
    xsize 420
    yfill True

    background "gui/overlay/main_menu.png"

style main_menu_vbox:
    xalign 1.0
    xoffset -30
    xmaximum 1200
    yalign 1.0
    yoffset -30

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_menu_title:
    properties gui.text_properties("title")

style main_menu_version:
    properties gui.text_properties("version")


## Game Menu 스크린 ###############################################################
##
## 게임 메뉴의 기본 틀입니다. 매개변수 title로 스크린 제목을 정하고, 배경, 제목,
## 그리고 navigation 스크린을 출력합니다.
##
## scroll 매개변수는, None, "viewport" 혹은 "vpgrid" 중 하나여야 합니다.
## transclude 명령어를 통해 다른 스크린을 이 스크린 내부에 불러옵니다.

screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    if main_menu:
        add gui.main_menu_background
    else:
        add gui.game_menu_background

    frame:
        style "game_menu_outer_frame"

        hbox:

            ## 탐색 섹션을 위한 공간 예약.
            frame:
                style "game_menu_navigation_frame"

            frame:
                style "game_menu_content_frame"

                if scroll == "viewport":

                    viewport:
                        yinitial yinitial
                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        vbox:
                            spacing spacing

                            transclude

                elif scroll == "vpgrid":

                    vpgrid:
                        cols 1
                        yinitial yinitial

                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        spacing spacing

                        transclude

                else:

                    transclude

    use navigation

    textbutton _("돌아가기"):
        style "return_button"

        action Return()

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")

style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 45
    top_padding 180

    background Transform("gui/overlay/game_menu.png",
        matrixcolor=TintMatrix("#ffd3e8") * SaturationMatrix(0.0))

style game_menu_navigation_frame:
    xsize 420
    yfill True

style game_menu_content_frame:
    left_margin 60
    right_margin 30
    top_margin 15

style game_menu_viewport:
    xsize 1380

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 15

style game_menu_label:
    xpos 75
    ysize 180

style game_menu_label_text:
    size 75
    color gui.accent_color
    yalign 0.5

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -45


## About 스크린 ###################################################################
##
## 이 스크린은 게임과 렌파이 엔진 크레딧과 저작권 정보를 표시합니다.
##
## 특별할 것이 없으므로 스크린을 새로 커스터마이징하여 만드는 예제이기도 합니다.

screen about():

    tag menu

    ## 이 use 명령어로 game_menu 스크린을 이 스크린 내에 불러옵니다. use 명령어
    ## 하위블럭(vbox 내용)은 game_menu 스크린 내 transclude 명령어가 있는 곳에
    ## 다시 불려집니다.
    use game_menu(_("버전정보"), scroll="viewport"):

        style_prefix "about"

        vbox:

            label "[config.name!t]"
            text _("버전 [config.version!t]\n")

            ## gui.about 의 내용은 보통 options.rpy에 있습니다.
            if gui.about:
                text "[gui.about!t]\n"

            text _("{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] 으로 만들어진 게임.\n\n[renpy.license!t]")


style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size


## Load 그리고 Save 스크린 ###########################################################
##
## 이 스크린은 세이브/로드에 쓰입니다. 거의 동일하기 때문에, file_slots 스크린을
## 불러와서 씁니다.
##
## https://www.renpy.org/doc/html/screen_special.html#save https://
## www.renpy.org/doc/html/screen_special.html#load

screen save():

    tag menu

    use file_slots(_("저장하기"))


screen load():

    tag menu

    use file_slots(_("불러오기"))


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("{} 페이지"), auto=_("자동 세이브"), quick=_("퀵세이브"))

    use game_menu(title):

        fixed:

            ## input이 세이브/로드 버튼보다 먼저 엔터에 반응하도록 합니다.
            order_reverse True

            ## 페이지 제목을 플레이어가 수정할 수 있음.
            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value

            ## 파일 슬롯 그리드.
            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.5

                spacing gui.slot_spacing

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1

                    button:
                        action FileAction(slot)

                        has vbox

                        add FileScreenshot(slot) xalign 0.5

                        text FileTime(slot, format=_("{#file_time}%A, %B %d %Y, %H:%M"), empty=_("빈 슬롯")):
                            style "slot_time_text"

                        text FileSaveName(slot):
                            style "slot_name_text"

                        key "save_delete" action FileDelete(slot)

            ## 페이지 이동 버튼.
            vbox:
                style_prefix "page"

                xalign 0.5
                yalign 1.0

                hbox:
                    xalign 0.5

                    spacing gui.page_spacing

                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}자동") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}퀵") action FilePage("quick")

                    ## 범위(1, 10)는 1부터 9까지 숫자를 제공합니다.
                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

                if config.has_sync:
                    if CurrentScreenName() == "save":
                        textbutton _("동기화 업로드"):
                            action UploadSync()
                            xalign 0.5
                    else:
                        textbutton _("동기화 다운로드"):
                            action DownloadSync()
                            xalign 0.5


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 75
    ypadding 5
    xalign 0.5

style page_label_text:
    textalign 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.text_properties("slot_button")


## Preferences 스크린 #############################################################
##
## Preferences 스크린에서는 각종 환경설정을 플레이어가 지정할 수 있습니다.
##
## https://www.renpy.org/doc/html/screen_special.html#preferences

screen preferences():

    tag menu

    use game_menu(_("환경설정"), scroll="viewport"):

        vbox:

            hbox:
                box_wrap True

                if renpy.variant("pc") or renpy.variant("web"):

                    vbox:
                        style_prefix "radio"
                        label _("화면 모드")
                        textbutton _("창 화면") action Preference("display", "window")
                        textbutton _("전체 화면") action Preference("display", "fullscreen")

                vbox:
                    style_prefix "check"
                    label _("넘기기")
                    textbutton _("읽지 않은 지문") action Preference("skip", "toggle")
                    textbutton _("선택지 이후") action Preference("after choices", "toggle")
                    textbutton _("화면 전환 효과") action InvertSelected(Preference("transitions", "toggle"))

                ## "radio_pref" 나 "check_pref" 를 추가하여 그 외에도 환경설정
                ## 항목을 추가할 수 있습니다.

            null height (4 * gui.pref_spacing)

            hbox:
                style_prefix "slider"
                box_wrap True

                vbox:

                    label _("텍스트 속도")

                    bar value Preference("text speed")

                    label _("자동 진행 시간")

                    bar value Preference("auto-forward time")

                vbox:

                    if config.has_music:
                        label _("배경음 음량")

                        hbox:
                            bar value Preference("music volume")

                    if config.has_sound:

                        label _("효과음 음량")

                        hbox:
                            bar value Preference("sound volume")

                            if config.sample_sound:
                                textbutton _("테스트") action Play("sound", config.sample_sound)


                    if config.has_voice:
                        label _("음성 음량")

                        hbox:
                            bar value Preference("voice volume")

                            if config.sample_voice:
                                textbutton _("테스트") action Play("voice", config.sample_voice)

                    if config.has_music or config.has_sound or config.has_voice:
                        null height gui.pref_spacing

                        textbutton _("모두 음소거"):
                            action Preference("all mute", "toggle")
                            style "mute_all_button"


style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 338

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.text_properties("check_button")

style slider_slider:
    xsize 525

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 675


## History 스크린 #################################################################
##
## 지난 대사록을 출력합니다. _history_list 에 저장된 대사 기록을 확인합니다.
##
## https://www.renpy.org/doc/html/history.html

screen history():

    tag menu

    ## 이 스크린은 내용이 아주 많을 수 있으므로 prediction을 끕니다.
    predict False

    use game_menu(_("대사록"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:

                ## history_height 이 None일 경우 레이아웃이 틀어지지 않게 합니
                ## 다.
                has fixed:
                    yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False

                        ## 화자 Character에 화자 색깔이 지정되어 있으면 불러옵니
                        ## 다.
                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("대사가 없습니다.")


## 이것은 대사록 화면에 표시할 수 있는 태그를 결정합니다.

define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5


## Help 스크린 ####################################################################
##
## 입력장치의 기능을 설명합니다. 각 입력장치별 설정은 keyboard_help, mouse_help,
## gamepad_help 스크린을 각각 불러와서 출력합니다.

screen help():

    tag menu

    default device = "keyboard"

    use game_menu(_("조작방법"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 23

            hbox:

                textbutton _("키보드") action SetScreenVariable("device", "keyboard")
                textbutton _("마우스") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("게임패드") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("엔터(Enter)")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("스페이스(Space)")
        text _("대사를 진행하되 선택지는 선택하지 않음.")

    hbox:
        label _("화살표 키")
        text _("UI 이동.")

    hbox:
        label _("이스케이프(Esc)")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("컨트롤(Ctrl)")
        text _("누르고 있는 동안 대사를 스킵.")

    hbox:
        label _("탭(Tab)")
        text _("대사 스킵 토글.")

    hbox:
        label _("페이지 업(Page Up)")
        text _("이전 대사로 롤백.")

    hbox:
        label _("페이지 다운(Page Down)")
        text _("이후 대사로 롤포워드.")

    hbox:
        label "H"
        text _("UI를 숨김.")

    hbox:
        label "S"
        text _("스크린샷 저장.")

    hbox:
        label "V"
        text _("{a=https://www.renpy.org/l/voicing}대사 읽어주기 기능{/a} 토글.")

    hbox:
        label "Shift+A"
        text _("접근성 메뉴를 엽니다.")


screen mouse_help():

    hbox:
        label _("클릭")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("가운데 버튼이나 휠버튼 클릭")
        text _("UI를 숨김.")

    hbox:
        label _("우클릭")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("휠 위로")
        text _("이전 대사로 롤백.")

    hbox:
        label _("휠 아래로")
        text _("이후 대사로 롤포워드.")


screen gamepad_help():

    hbox:
        label _("오른쪽 트리거(RT)\nA버튼/아래 버튼")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("왼쪽 트리거\n왼쪽 어깨")
        text _("이전 대사로 롤백.")

    hbox:
        label _("오른쪽 범퍼(RB)")
        text _("이후 대사로 롤포워드.")

    hbox:
        label _("D-Pad, 아날로그 스틱")
        text _("UI 이동.")

    hbox:
        label _("Start, Guide, B/Right Button")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("Y버튼/위 버튼")
        text _("UI를 숨김.")

    textbutton _("조정") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 12

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 375
    right_padding 30

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0



################################################################################
## 그 외 스크린
################################################################################


## Confirm 스크린 #################################################################
##
## 게임 입력 관련 예/아니오 질문을 플레이어에게 할 때 이 스크린을 표시합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#confirm

screen confirm(message, yes_action, no_action):

    ## 이 스크린이 출력 중일 때 다른 스크린과 상호작용할 수 없게 합니다.
    modal True

    zorder 200

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        vbox:
            xalign .5
            yalign .5
            spacing 45

            label _(message):
                style "confirm_prompt"
                xalign 0.5

            hbox:
                xalign 0.5
                spacing 150

                textbutton _("네") action yes_action
                textbutton _("아니오") action no_action

    ## 우클릭과 esc는 '아니오'를 입력하는 것과 같습니다.
    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Frame(Transform("gui/frame.png",
        matrixcolor=TintMatrix("#ffd3e8") * SaturationMatrix(0.0)),
        gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5

style confirm_prompt_text:
    textalign 0.5
    layout "subtitle"

style confirm_button:
    properties gui.button_properties("confirm_button")

style confirm_button_text:
    properties gui.text_properties("confirm_button")


## Skip indicator 스크린 ##########################################################
##
## Skip_indicator 스크린은 스킵 중일 때 "스킵 중"을 표시하기 위해 출력됩니다.
##
## https://www.renpy.org/doc/html/screen_special.html#skip-indicator

screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        hbox:
            spacing 9

            text _("넘기는 중")

            text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"


## 이 transform으로 화살표를 순서대로 페이드인/페이드아웃합니다.
transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat

transform textbox_fade:
    on show:
        alpha 0.0
        linear 0.5 alpha 1.0
    on hide:
        linear 0.3 alpha 0.0

style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:
    ## BLACK RIGHT-POINTING SMALL TRIANGLE 글리프가 있는 글꼴을 사용해야 합니다.
    font "DejaVuSans.ttf"


## Notify 스크린 ##################################################################
##
## Notify 스크린으로 플레이어에게 메시지를 출력합니다. (예를 들어 '퀵세이브 완
## 료'나 '스크린샷 저장 완료')
##
## https://www.renpy.org/doc/html/screen_special.html#notify-screen

screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")


## NVL 스크린 #####################################################################
##
## NVL모드 대사와 선택지를 출력합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#nvl


screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox:
            spacing gui.nvl_spacing

        ## vpgrid나 vbox 내에 대사를 출력합니다.
        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)

        ## 주어진 경우 메뉴를 표시합니다. config.narrator_menu가 True로 설정된
        ## 경우 메뉴가 잘못 표시될 수 있습니다.
        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            fixed:
                yfit gui.nvl_height is None

                if d.who is not None:

                    text d.who:
                        id d.who_id

                text d.what:
                    id d.what_id


## 동시에 출력될 수 있는 NVL 대사의 최대치를 조정합니다.
define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    textalign gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    textalign gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    textalign gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.text_properties("nvl_button")


## Bubble screen ###############################################################
##
## 말풍선 화면은 말풍선을 사용할 때 플레이어에게 대화를 표시하는 데 사용됩니다.
## 말풍선 화면은 말풍선 화면과 동일한 매개변수를 사용하며, "what" 아이디로 표시
## 가능 항목을 생성해야 하며, "namebox", "who", "window" 아이디로 표시 가능 항목
## 을 생성할 수 있습니다.
##
## https://www.renpy.org/doc/html/bubble.html#bubble-screen

screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

        default ctc = None
        showif ctc:
            add ctc

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}



################################################################################
## 모바일 버전
################################################################################

style pref_vbox:
    variant "medium"
    xsize 675

## 마우스가 없고 화면이 작을 가능성이 높으므로, 퀵메뉴 버튼의 크기를 키우고 가짓
## 수를 줄입니다.
screen quick_menu():
    variant "touch"

    zorder 100

    if quick_menu:

        hbox:
            style "quick_menu"
            style_prefix "quick"

            textbutton _("되감기") action Rollback()
            textbutton _("넘기기") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("자동진행") action Preference("auto-forward", "toggle")
            textbutton _("메뉴") action ShowMenu()


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    # background "gui/phone/textbox.png"
    background Solid("#000000b3")

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background "gui/phone/overlay/main_menu.png"

style game_menu_outer_frame:
    variant "small"
    background "gui/phone/overlay/game_menu.png"

style game_menu_navigation_frame:
    variant "small"
    xsize 510

style game_menu_content_frame:
    variant "small"
    top_margin 0

style game_menu_viewport:
    variant "small"
    xsize 1305

style pref_vbox:
    variant "small"
    xsize 600

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 900


## 엔딩크레딧 화면
screen ending_credit(skippable=True):
    modal True
    add Solid("#000")

    if skippable:
        button:
            xfill True
            yfill True
            background None
            action Return()

    vbox at credit(duration=40.0):
        spacing 24

        # 위→아래 방식은 아래쪽 줄이 먼저 화면에 들어옵니다.
        text "Thank you for playing" size 50 xalign 0.5
        null height 80
        text "폰트  눈누 - Pretendard" xalign 0.5
        null height 40
        text "효과음  SoundEffect Lab, Pixabay, Freesound" xalign 0.5
        null height 40
        text "음악  SunoAI, Claude" xalign 0.5
        null height 40
        text "일러스트  PixAI, ChatGPT" xalign 0.5
        null height 40
        text "프로그래밍  안진호" xalign 0.5
        null height 40
        text "시나리오  안진호, Claude" xalign 0.5
        null height 40
        text "제작  안진호" xalign 0.5
        null height 40
        text "기획  안진호" xalign 0.5
        null height 80
        text "그날 - 그럼에도, 오늘을" size 56 xalign 0.5

    if skippable:
        textbutton _("건너뛰기 >"):
            xalign 0.97
            yalign 0.03
            action Return()

    timer 41.0 action Return()


################################################################################
## 움직이는 타이틀 화면
################################################################################

## ── 이미지 ─────────────────────────────────────────

image title_bg       = "images/title/title_bg.png"
image title_lanterns = "images/title/title_lanterns.png"
image title_glow     = "images/title/title_glow.png"
image title_logo     = "images/title/logo.png"
image white          = Solid("#ffffff")

## 화면을 빈틈없이 덮도록 확대 비율을 자동으로 계산(1888x1056)합니다.
define title_w = 1888
define title_h = 1056
define title_cover = max(config.screen_width / 1888.0, config.screen_height / 1056.0)

## 거리 끝 하얀 빛의 중심 (그림 기준 비율). title_glow.png를 이 자리에 맞춰 만들었습니다.
define title_glow_center = (0.368, 0.625)


## ── 움직임 ─────────────────────────────────────────

## 화면 전체가 아주 천천히 다가왔다 물러납니다. (숨 쉬는 느낌)
## 확대의 기준점을 거리 끝 빛에 두어, 그 빛 쪽으로 다가가는 것처럼 보입니다.
transform title_drift(base=1.0):
    subpixel True
    align title_glow_center
    zoom base
    ease 25.0 zoom base * 1.03
    ease 25.0 zoom base
    repeat

## 등불 깜박임. 일부러 박자를 고르지 않게 해서 기계적으로 보이지 않게 합니다.
transform lantern_flicker:
    alpha 0.0
    block:
        ease 1.8 alpha 0.55
        ease 0.9 alpha 0.35
        ease 1.4 alpha 0.6
        ease 2.2 alpha 0.2
        repeat

## 거리 끝 하얀 빛이 천천히 밝아졌다 흐려집니다.
transform glow_breath:
    alpha 0.5
    block:
        ease 4.0 alpha 0.85
        ease 4.0 alpha 0.5
        repeat

## 떨어지는 잎이 돌면서 내려옵니다.
transform leaf_spin_cw:
    rotate 0
    linear 5.0 rotate 360
    repeat

transform leaf_spin_ccw:
    rotate 0
    linear 7.0 rotate -360
    repeat

## 로고가 살짝 떠오르며 나타납니다.
transform logo_in:
    alpha 0.0
    yoffset 10
    pause 0.6
    ease 1.5 alpha 1.0 yoffset 0


## ── 떨어지는 잎 (파티클) ───────────────────────────
## count: 화면에 동시에 있는 잎 수 / xspeed: 옆으로 흐르는 속도(음수면 왼쪽)
## yspeed: 떨어지는 속도 / fast=True: 처음부터 화면에 잎이 차 있는 상태로 시작

image title_leaves_ginkgo = SnowBlossom(
    At("images/title/leaf_ginkgo.png", leaf_spin_cw),
    count=6, xspeed=(20, 60), yspeed=(50, 110), fast=True)

image title_leaves_maple = SnowBlossom(
    At("images/title/leaf_maple.png", leaf_spin_ccw),
    count=4, xspeed=(10, 50), yspeed=(40, 90), fast=True)


## ── 타이틀 화면 레이어 ─────────────────────────────
## screens.rpy의 main_menu 화면에서 이 화면을 불러 씁니다.

screen title_layers():

    ## 배경·등불·빛은 한 묶음으로 같이 움직여야 위치가 어긋나지 않습니다.
    fixed:
        xysize (title_w, title_h)
        at title_drift(title_cover)
        add "title_bg"
        add "title_lanterns" at lantern_flicker
        add "title_glow" at glow_breath

    add "title_leaves_maple"
    add "title_leaves_ginkgo"

    ## 위쪽 등불 줄과 둘째 줄 사이의 하늘 자리입니다.
    add "title_logo" pos (110, 120) at logo_in


## ── "시작하기"를 눌렀을 때: 하얀 빛이 화면을 덮으며 시작 ──

transform whiteout_glow:
    align title_glow_center
    alpha 0.6
    zoom title_cover
    ease 1.0 zoom title_cover * 1.8 alpha 1.0

transform whiteout_fill:
    alpha 0.0
    pause 0.3
    ease 0.9 alpha 1.0

screen title_whiteout():
    modal True
    add "title_glow" at whiteout_glow
    add "white" at whiteout_fill
    timer 1.3 action Start()


## ── 타이틀 메뉴 ───────────────────────────────────
## 왼쪽 아래 길바닥 자리에 세로로 놓입니다.
## 밝은 안개(화면 가운데 높이)와 스케치북(오른쪽 아래)을 피한 자리입니다.

## 메뉴 위치와 간격. 그림 기준 좌표라 여기만 고치면 전체가 같이 움직입니다.
define title_menu_pos = (120, 400)
define title_menu_spacing = 24

## 글자 색
define title_menu_idle  = "#fff6ec"   # 평소: 따뜻한 흰색
define title_menu_hover = "#ffd68c"   # 마우스를 올렸을 때: 등불 같은 금빛
define title_menu_ink   = "#462834"   # 테두리: 로고와 같은 자두색 계열

style title_menu_button is button:
    background None
    padding (28, 4, 12, 4)
    hover_foreground Transform(
        Text("›", font=gui.interface_text_font, size=36, color=title_menu_hover,
            outlines=[ (3, title_menu_ink + "c8", 0, 0) ]),
        xpos=2, yalign=0.5)

style title_menu_button_text is button_text:
    font gui.interface_text_font
    size 42
    idle_color title_menu_idle
    hover_color title_menu_hover
    selected_color title_menu_hover
    insensitive_color "#fff6ec80"
    outlines [ (3, title_menu_ink + "c8", 0, 0), (8, "#28161e40", 0, 2) ]
    kerning 1.0

## 마우스를 올리면 오른쪽으로 살짝 밀리고, 앞에 작은 표시가 생깁니다.
transform title_menu_item:
    on idle:
        ease 0.18 xoffset 0
    on hover:
        ease 0.18 xoffset 10

transform title_menu_in(delay=0.0):
    alpha 0.0
    xoffset -12
    pause (1.2 + delay)
    ease 0.6 alpha 1.0 xoffset 0

screen title_menu():

    vbox:
        pos title_menu_pos
        spacing title_menu_spacing

        textbutton "시작하기":
            style "title_menu_button"
            action Show("title_whiteout")
            at title_menu_in(0.0), title_menu_item

        textbutton "불러오기":
            style "title_menu_button"
            action ShowMenu("load")
            at title_menu_in(0.1), title_menu_item

        textbutton "환경설정":
            style "title_menu_button"
            action ShowMenu("preferences")
            at title_menu_in(0.2), title_menu_item

        textbutton "크레딧":
            style "title_menu_button"
            action Start("ending_credit")
            at title_menu_in(0.3), title_menu_item
        
        if renpy.variant("pc"):
            textbutton "종료":
                style "title_menu_button"
                action Quit(confirm=True)
                at title_menu_in(0.4), title_menu_item



################################################################################
## 아이템 도감 화면
################################################################################

## ── 아이템 데이터 ─────────────────────────────────────────
define ITEMS = [
    {
        "id": "umbrella",
        "name": "노란 우산의 기억",
        "route": "소은",
        "image": "images/items/item_umbrella.png",
        "desc": "비 오는 날, 공원 나무 밑에 서 있던 내게 노란 우산이 다가왔다.",
    },
    {
        "id": "rooftop_key",
        "name": "옥상 열쇠",
        "route": "태은",
        "image": "images/items/item_key.png",
        "desc": "원래 잠겨 있어야 하는 문의 열쇠.",
    },
    {
        "id": "dain_photo",
        "name": "다인과 찍은 사진",
        "route": "다인",
        "image": "images/items/item_photo.png",
        "desc": "다인이 내 볼을 양쪽으로 잡아당기며 웃고 있다.",
    },
    {
        "id": "pencil",
        "name": "몽당연필",
        "route": "소은",
        "image": "images/items/item_pencil.png",
        "desc": "손가락 한 마디만 남은 연필. 끝이 둥글게 닳아 있다.",
    },
    {
        "id": "watch",
        "name": "멈춘 손목시계",
        "route": "태은",
        "image": "images/items/item_watch.png",
        "desc": "낡은 가죽 끈에, 바늘이 멈춘 시계.",
    },
    {
        "id": "keyring",
        "name": "토끼 키링",
        "route": "다인",
        "image": "images/items/item_rabbit.png",
        "desc": "다인의 가방에 걸려 있던 토끼 키링.",
    },
]

## 크기 조절 (프로젝트 해상도가 1280x720이면 ITEM_BOX 120, ITEM_DESC_WIDTH 300 정도로 줄이세요)
define ITEM_BOX = 160          # 아이템 칸 한 변 길이(px)
define ITEM_DESC_WIDTH = 420   # 오른쪽 설명 영역 너비(px)


## ── 도감 기록 (회차가 바뀌어도 남는 영구 기록) ─────────────────────────────────────────
default persistent.items_found = set()

init python:

    def item_name(item_id):
        for i in ITEMS:
            if i["id"] == item_id:
                return i["name"]
        return item_id

    def get_item(item_id):
        ## 이번 회차용 변수 (엔딩 조건에 쓰는 item_umbrella 등)
        setattr(store, "item_" + item_id, True)
        ## 도감용 영구 기록
        persistent.items_found.add(item_id)
        ## 획득 알림
        renpy.notify("아이템 획득: " + item_name(item_id))


## ── 도감 화면 ─────────────────────────────────────────
screen collection():

    tag menu

    default selected = None

    $ found_count = len([i for i in ITEMS if i["id"] in persistent.items_found])

    use game_menu(_("도감")):

        hbox:
            spacing 50

            ## 왼쪽: 아이템 칸
            vbox:
                spacing 20

                text "수집 " + str(found_count) + " / " + str(len(ITEMS)) size 22 color "#ffffffaa"

                ## 아이템 개수를 바꾸면 여기 숫자(가로 3 × 세로 2)도 맞춰 주세요.
                grid 3 2:
                    spacing 20

                    for item in ITEMS:
                        $ found = item["id"] in persistent.items_found

                        button:
                            xysize (ITEM_BOX, ITEM_BOX)
                            background "#ffffff14"
                            hover_background "#ffffff33"
                            selected_background "#ffffff4d"
                            insensitive_background "#0000004d"
                            sensitive found
                            action SetScreenVariable("selected", item)

                            if found:
                                if renpy.loadable(item["image"]):
                                    add item["image"] fit "contain" xysize (ITEM_BOX - 24, ITEM_BOX - 24) align (0.5, 0.5)
                                else:
                                    text item["name"] size 20 text_align 0.5 align (0.5, 0.5)
                            else:
                                text "?" size 64 color "#ffffff55" align (0.5, 0.5)

            ## 오른쪽: 설명
            vbox:
                xsize ITEM_DESC_WIDTH
                spacing 16

                if selected:
                    text selected["name"] size 34
                    text selected["route"] + " 쪽으로 이어진 물건" size 20 color "#ffffff99"
                    null height 10
                    text selected["desc"] size 24
                else:
                    text "보고 싶은 물건을 고르세요." size 24 color "#ffffff88"



################################################################################
## 스토리라인 (분기 흐름도)
################################################################################
## 15개 label을 갈라지고 합쳐지는 흐름도로 보여 주고, 누르면 그 label로 이동합니다.
## 엔딩 3개만 제목 + 그림 카드, 나머지는 텍스트 버튼입니다.
## 한 번 본 장면만 누를 수 있고, 아직 못 본 장면은 흐리게 잠겨 있습니다.

## ── 장면 목록 ─────────────────────────────────────────
## label  : script.rpy에 있는 label 이름 (철자가 정확히 같아야 합니다)
## route  : 버튼 색을 정하는 인물 (이준 / 소은 / 태은 / 다인)
## ending : True면 그림이 들어가는 엔딩 카드
## image  : 엔딩 그림 경로. 지금은 None(그림 없음)입니다.

define STORYLINE = [
    {"label": "start",           "no": "1",   "route": "이준", "title": "그날로부터, 1년"},
    {"label": "ch2",             "no": "2",   "route": "이준", "title": "균열과 제안"},
    {"label": "ch2_keep_soeun",  "no": "2-1", "route": "소은", "title": "사진 한 장을 내놓다"},
    {"label": "ch2_keep_dain",   "no": "2-2", "route": "다인", "title": "첫 기억을 내놓다"},
    {"label": "ch3",             "no": "3",   "route": "이준", "title": "첫 번째 회귀"},
    {"label": "ch4",             "no": "4",   "route": "이준", "title": "두 번째 시도"},
    {"label": "ch4_stay_taeeun", "no": "4-1", "route": "태은", "title": "끝까지 듣다"},
    {"label": "ch4_go_dain",     "no": "4-2", "route": "다인", "title": "부르는 쪽으로"},
    {"label": "ch5",             "no": "5",   "route": "이준", "title": "옅어지는 것들"},
    {"label": "ch5_stay_taeeun", "no": "5-1", "route": "태은", "title": "내가 널 기억할게"},
    {"label": "ch5_go_soeun",    "no": "5-2", "route": "소은", "title": "용기를 낸 대가"},
    {"label": "ch6",             "no": "6",   "route": "이준", "title": "마지막 하루"},
    {"label": "end_soeun",       "no": "end", "route": "소은", "title": "다 그리면 알려줄게", "kind": "소은 엔딩", "ending": True, "image": "images/cg end_soeun.png"},
    {"label": "end_taeeun",      "no": "end", "route": "태은", "title": "오랜만의 평범함",    "kind": "태은 엔딩", "ending": True, "image": "images/cg end_taeeun.png"},
    {"label": "end_dain",        "no": "end", "route": "다인", "title": "여전히, 여기",       "kind": "다인 엔딩", "ending": True, "image": "images/cg end_dain.png"},
]

## 흐름도의 줄 구성 (위에서 아래로). 한 줄에 2개면 갈림길, 3개면 엔딩 갈림길.
## 갈림길 안에서는 왼쪽 → 오른쪽 순서로 놓입니다.
define SL_ROWS = [
    ["start"],
    ["ch2"],
    ["ch2_keep_soeun", "ch2_keep_dain"],
    ["ch3"],
    ["ch4"],
    ["ch4_stay_taeeun", "ch4_go_dain"],
    ["ch5"],
    ["ch5_stay_taeeun", "ch5_go_soeun"],
    ["ch6"],
    ["end_soeun", "end_taeeun", "end_dain"],
]

## 테스트용: True로 바꾸면 안 본 장면도 전부 열립니다. 배포 전에는 꼭 False로.
define STORYLINE_UNLOCK_ALL = False

## 색
define SL_ROUTE_COLOR = {"이준": "#919191", "소은": "#e0a040", "태은": "#89a5c0", "다인": "#121d2b"}
define SL_ACCENT = "#c4839f"      # 제목 탭 · 위쪽 띠
define SL_PAPER = "#f6f3ee"       # 패널 바탕
define SL_INK = "#3a3640"         # 글자
define SL_INK_SOFT = "#3a364099"  # 흐린 글자
define SL_LOCKED = "#e2e0e7"      # 잠긴 버튼 바탕
define SL_LOCKED_INK = "#3a364055"
define SL_LINE = "#b8b2c4"        # 연결선

## 크기 (1920x1080 기준. 다른 해상도에서는 자동으로 비율을 맞춥니다)
define SL_NODE_W = 380     # 텍스트 버튼 너비
define SL_NODE_H = 60      # 텍스트 버튼 높이
define SL_ROW_GAP = 64     # 줄 사이 간격 (연결선 길이)
define SL_PAIR_DX = 250    # 갈림길 버튼이 가운데서 벌어지는 거리
define SL_END_DX = 470     # 엔딩 카드가 가운데서 벌어지는 거리
define SL_CARD_W = 400     # 엔딩 카드 너비
define SL_CARD_HEAD = 52   # 엔딩 카드 제목 칸 높이
define SL_CARD_IMG = 225   # 엔딩 그림 높이 (너비 400과 16:9)
define SL_LINE_W = 4       # 연결선 두께


## ── 기능 ─────────────────────────────────────────

init python:

    SL_BY_LABEL = {e["label"]: e for e in STORYLINE}

    ## 1920x1080 기준 크기를 지금 해상도에 맞게 바꿔 줌
    def sl(n):
        return int(round(n * config.screen_width / 1920.0))

    ## 한 번이라도 본 label인지 (세이브와 상관없이 기록됨)
    def storyline_unlocked(entry):
        return STORYLINE_UNLOCK_ALL or renpy.seen_label(entry["label"])

    ## 버튼 위치와 연결선 계산
    ## 돌려주는 값: 캔버스 너비, 높이, [(장면, 가운데 x, 위쪽 y, 엔딩 여부)], [(x, y, 너비, 높이) 선]
    def storyline_layout():
        cw = sl(1500)
        cx = cw // 2
        t = max(2, sl(SL_LINE_W))

        nodes = []
        lines = []
        y = sl(50)
        prev = None

        for row in SL_ROWS:
            n = len(row)
            if n == 1:
                xs = [cx]
            elif n == 2:
                xs = [cx - sl(SL_PAIR_DX), cx + sl(SL_PAIR_DX)]
            else:
                xs = [cx - sl(SL_END_DX), cx, cx + sl(SL_END_DX)]

            is_end = all(SL_BY_LABEL[l].get("ending", False) for l in row)
            h = sl(SL_CARD_HEAD + SL_CARD_IMG) if is_end else sl(SL_NODE_H)

            ## 위 줄과 이어 주는 선: 내려오는 선 → 가로선 → 내려가는 선
            if prev:
                pxs, pbottom = prev
                mid = (pbottom + y) // 2
                for x in pxs:
                    lines.append((x - t // 2, pbottom, t, mid - pbottom))
                for x in xs:
                    lines.append((x - t // 2, mid, t, y - mid))
                allx = pxs + xs
                if min(allx) != max(allx):
                    lines.append((min(allx) - t // 2, mid - t // 2, max(allx) - min(allx) + t, t))

            for l, x in zip(row, xs):
                nodes.append((SL_BY_LABEL[l], x, y, is_end))

            prev = (xs, y + h)
            y = y + h + sl(SL_ROW_GAP)

        ch = y - sl(SL_ROW_GAP) + sl(60)
        return cw, ch, nodes, lines

    ## 이동하기 전에 아이템 상태 정리
    ## - 처음(start)부터 보면: 새 게임처럼 아이템 없이 시작
    ## - 그 외 장면에서 보면: 아이템을 모두 들고 시작 → 엔딩 선택지 3개가 모두 열림
    def storyline_prepare(target):
        grant = (target != "start")
        for item_id in ["umbrella", "pencil", "rooftop_key", "watch", "dain_photo", "keyring"]:
            setattr(store, "item_" + item_id, grant)

    ## 버튼을 눌렀을 때의 동작
    ## 타이틀 화면에서는 바로 이동, 게임 중에는 한 번 확인하고 이동
    def storyline_action(label):
        go = [SetField(persistent, "storyline_target", label), Start("storyline_jump")]
        if store.main_menu:
            return go
        return Confirm("지금 진행 중인 내용은 저장되지 않아요.\n이 장면으로 이동할까요?", go)


## 실제 이동은 여기를 거쳐서 합니다.
label storyline_jump:
    $ _sl_target = persistent.storyline_target or "start"
    $ storyline_prepare(_sl_target)

    ## 이전 장면의 연출(회상 톤, 음악 등)이 남지 않도록 정리
    camera
    scene black
    stop music fadeout 1.0
    stop sound
    window hide

    ## 이 장면의 준비 label(sl_setup_라벨이름)이 있으면 먼저 실행해서
    ## 배경 · 캐릭터 · 음악을 깔아 둡니다.
    if renpy.has_label("sl_setup_" + _sl_target):
        call expression ("sl_setup_" + _sl_target) from _call_expression

    $ renpy.block_rollback()

    $ renpy.jump(_sl_target)

## 준비 label (이어지는 라벨로 이동할 때 검은 화면이 뜨는 현상 수정)
label sl_setup_ch2_keep_soeun:
    scene bg alley
    show taeeun normal at character_size
    play music "bgm_price.ogg"
    return

label sl_setup_ch2_keep_dain:
    scene bg alley
    show taeeun normal at character_size
    play music "bgm_price.ogg"
    return

label sl_setup_ch4_stay_taeeun:
    scene bg rooftop_day
    show taeeun normal at character_size
    return

label sl_setup_ch4_go_dain:
    scene bg rooftop_day
    show taeeun normal at character_size
    return

label sl_setup_ch5_stay_taeeun:
    scene bg rooftop_day
    show taeeun normal at character_size
    return

label sl_setup_ch5_go_soeun:
    scene bg rooftop_day
    show taeeun normal at character_size
    return


## ── 스토리라인 화면 ─────────────────────────────────────────

screen storyline():

    tag menu

    $ cw, ch, nodes, lines = storyline_layout()
    $ total = len(STORYLINE)
    $ seen_count = len([e for e in STORYLINE if storyline_unlocked(e)])

    key "game_menu" action Return()

    ## 배경 (뒤 화면을 어둡게)
    if main_menu:
        add gui.main_menu_background
    else:
        add gui.game_menu_background
    add Solid("#16131dcc")

    ## 왼쪽 위 제목 탭
    frame:
        pos (0, sl(40))
        padding (sl(110), sl(16), sl(44), sl(16))
        background SL_ACCENT

        hbox:
            spacing sl(22)
            text "스토리라인" size sl(36) color "#ffffff"
            text (str(seen_count) + " / " + str(total)) size sl(24) color "#ffffffbb" yalign 0.5

    ## 가운데 패널
    frame:
        xalign 0.5
        ypos sl(150)
        xysize (sl(1560), sl(800))
        padding (0, 0)
        background SL_PAPER

        fixed:

            ## 위쪽 색 띠
            add Solid(SL_ACCENT) xysize (sl(1560), sl(8))

            ## 흐름도 (마우스 휠 · 드래그로 위아래 이동)
            viewport id "sl_vp":
                pos (sl(30), sl(8))
                xysize (sl(1500), sl(792))
                mousewheel True
                draggable True

                fixed:
                    xysize (cw, ch)

                    ## 연결선
                    for r in lines:
                        add Solid(SL_LINE) pos (r[0], r[1]) xysize (r[2], r[3])

                    ## 버튼 · 엔딩 카드
                    for e, x, y, is_end in nodes:
                        if is_end:
                            use storyline_ending(e, x, y)
                        else:
                            use storyline_node(e, x, y)

            ## 오른쪽 스크롤바
            vbar value YScrollValue("sl_vp"):
                style "vscrollbar"
                xalign 1.0
                xoffset -sl(12)
                ypos sl(40)
                ysize sl(720)
                unscrollable "hide"

    ## 뒤로가기
    textbutton "< 뒤로가기":
        pos (sl(60), config.screen_height - sl(80))
        yanchor 0.5
        padding (sl(26), sl(10))
        background "#ffffff"
        hover_background "#e6ecf4"
        text_size sl(24)
        text_color SL_INK
        text_hover_color SL_ACCENT
        action Return()


## 텍스트 버튼 (본편 · 분기)
screen storyline_node(e, x, y):

    $ unlocked = storyline_unlocked(e)
    $ color = SL_ROUTE_COLOR.get(e["route"], SL_ACCENT)

    button:
        pos (x, y)
        xanchor 0.5
        xysize (sl(SL_NODE_W), sl(SL_NODE_H))
        padding (0, 0)
        background ("#ffffff" if unlocked else SL_LOCKED)
        hover_background (color + "33")
        sensitive unlocked
        action storyline_action(e["label"])

        fixed:
            ## 왼쪽 색 띠
            add Solid(color if unlocked else "#c9c5d1") xysize (sl(8), sl(SL_NODE_H))

            hbox:
                align (0.5, 0.5)
                spacing sl(14)
                text e["no"] size sl(22) color (color if unlocked else SL_LOCKED_INK) yalign 0.5
                text e["title"] size sl(26) color (SL_INK if unlocked else SL_LOCKED_INK) hover_color color yalign 0.5


## 엔딩 카드 (제목 + 그림)
screen storyline_ending(e, x, y):

    $ unlocked = storyline_unlocked(e)
    $ color = SL_ROUTE_COLOR.get(e["route"], SL_ACCENT)
    $ img = e.get("image")

    button:
        pos (x, y)
        xanchor 0.5
        xysize (sl(SL_CARD_W), sl(SL_CARD_HEAD + SL_CARD_IMG))
        padding (0, 0)
        background ("#ffffff" if unlocked else SL_LOCKED)
        hover_foreground Solid("#ffffff2e")
        sensitive unlocked
        action storyline_action(e["label"])

        vbox:
            ## 제목 칸
            frame:
                xysize (sl(SL_CARD_W), sl(SL_CARD_HEAD))
                padding (0, 0)
                background (color if unlocked else "#c9c5d1")

                hbox:
                    align (0.5, 0.5)
                    spacing sl(12)
                    text e["kind"] size sl(18) color "#ffffffcc" yalign 0.5
                    text e["title"] size sl(24) color "#ffffff" yalign 0.5

            ## 그림 칸
            fixed:
                xysize (sl(SL_CARD_W), sl(SL_CARD_IMG))

                if not unlocked:
                    text "?" size sl(96) color "#ffffffdd" align (0.5, 0.5)

                elif img and renpy.loadable(img):
                    add img fit "contain" xysize (sl(SL_CARD_W), sl(SL_CARD_IMG)) align (0.5, 0.5)

                else:
                    ## 그림이 아직 없을 때
                    vbox:
                        align (0.5, 0.5)
                        spacing sl(6)
                        text e["kind"] size sl(36) color color xalign 0.5
                        text "ENDING" size sl(18) color SL_INK_SOFT xalign 0.5